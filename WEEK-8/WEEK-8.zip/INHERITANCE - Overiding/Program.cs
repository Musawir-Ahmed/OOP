﻿using System;
using System.Collections;

namespace INHERITANCE
{

    class Student_manager
    {
        private ArrayList Hostelite_List = new ArrayList();
        private ArrayList DayScholar_List = new ArrayList();

        private Student_manager()
        { }
        static Student_manager studentManager_object;
        public static Student_manager object_existance()
        {
            if (studentManager_object == null)
            {
                studentManager_object = new Student_manager();
            }
            return studentManager_object;
        }

        public void add_hostellite(string name, string session, bool isDayScholar, string EntryTestMarks, string MatricMarks, string FscMarks, string roomNumber, bool isFridgeAvilable, bool isInternetAvailable, string subjects_registered)
        {
            Hostelite Hostelite_object = new Hostelite();
            Hostelite_object.name = name;
            Hostelite_object.session = session;
            Hostelite_object.isDayScholar = isDayScholar;
            Hostelite_object.EntryTestMarks = EntryTestMarks;
            Hostelite_object.MatricMarks = MatricMarks;
            Hostelite_object.FscMarks = FscMarks;
            Hostelite_object.set_roomNumber(roomNumber);
            Hostelite_object.set_isFridgeAvilable(isFridgeAvilable);
            Hostelite_object.set_isInternetAvailable(isInternetAvailable);
            Hostelite_object.subjects_registered = subjects_registered;
            Hostelite_List.Add(Hostelite_object);
        }
        public void add_dayscholar(string name, string session, bool isDayScholar, string EntryTestMarks, string MatricMarks, string FscMarks, string pickUPpoint, string BusNo, String pickupDistance, string subjects_registered)
        {
            DayScholarBusfee DayScholarBusfee_object = new DayScholarBusfee();
            DayScholarBusfee_object.name = name;
            DayScholarBusfee_object.session = session;
            DayScholarBusfee_object.isDayScholar = isDayScholar;
            DayScholarBusfee_object.EntryTestMarks = EntryTestMarks;
            DayScholarBusfee_object.MatricMarks = MatricMarks;
            DayScholarBusfee_object.FscMarks = FscMarks;
            DayScholarBusfee_object.set_BusNo(BusNo);
            DayScholarBusfee_object.set_pickUPpoint(pickUPpoint);
            DayScholarBusfee_object.set_pickupDistance(pickupDistance);
            DayScholarBusfee_object.subjects_registered = subjects_registered;
            DayScholar_List.Add(DayScholarBusfee_object);

        }

        public ArrayList viewAll_Day_scholar()
        {
            ArrayList all_users = new ArrayList();
            for (int x = 0; x < DayScholar_List.Count; x++)
            {
                all_users.Add(DayScholar_List[x]);
            }
            return all_users;
        }

        public ArrayList viewAll_Hostillite()
        {
            ArrayList all_users = new ArrayList();
            for (int x = 0; x < Hostelite_List.Count; x++)
            {
                all_users.Add(Hostelite_List[x]);
            }
            return all_users;
        }

        public DayScholarBusfee viewAll_Day_scholar_fee(string name, string session)
        {

            for (int x = 0; x < DayScholar_List.Count; x++)
            {
                DayScholarBusfee temp = (DayScholarBusfee)DayScholar_List[x];

                if (temp.name == name && temp.session == session)
                {
                    return temp;
                }
            }

            return null;
        }

        public Hostelite viewAll_hostelite_fee(string name, string session)
        {

            for (int x = 0; x < DayScholar_List.Count; x++)
            {
                Hostelite temp = (Hostelite)Hostelite_List[x];

                if (temp.name == name && temp.session == session)
                {
                    return temp;
                }
            }

            return null;
        }




    }


    class Student
    {
        public string name = "";
        public string session = "";
        public bool isDayScholar = false;
        public string EntryTestMarks = "";
        public string MatricMarks = "";
        public string FscMarks = "";
        public string subjects_registered = "";

        public virtual int get_fee(string subjects_registered)
        {
            int subjects_registered_temp;
            int fee;
            subjects_registered_temp = int.Parse(subjects_registered);
            fee = subjects_registered_temp * 4000;
            return fee;
        }
    }

    class Hostelite : Student
    {
        private string roomNumber = "";
        private bool isFridgeAvilable = false;
        private bool isInternetAvailable = false;
        public void set_roomNumber(string roomNumber)
        {
            this.roomNumber = roomNumber;
        }

        public void set_isFridgeAvilable(bool isFridgeAvilable)
        {
            this.isFridgeAvilable = isFridgeAvilable;
        }

        public void set_isInternetAvailable(bool isInternetAvailable)
        {
            this.isInternetAvailable = isInternetAvailable;
        }

        public string get_roomNumber()
        {
            return this.roomNumber;
        }

        public bool get_isFridgeAvilable()
        {
            return this.isFridgeAvilable;
        }

        public bool get_isInternetAvailable()
        {
            return this.isInternetAvailable;
        }

        public override int get_fee(string subjects_registered)
        {
            int basic_fee = base.get_fee(this.subjects_registered);
            if (this.isFridgeAvilable == true && this.isInternetAvailable == true)
            {
                basic_fee = basic_fee + 2000;
            }
            else if (this.isFridgeAvilable == true || this.isInternetAvailable == true)
            {
                basic_fee = basic_fee + 1000;
            }

            return basic_fee;

        }
    }
    class DayScholarBusfee : Student
    {
        string pickUPpoint = "";
        string BusNo = "";
        String pickupDistance = "";
        public void set_pickUPpoint(string pickUPpoint)
        {
            this.pickUPpoint = pickUPpoint;
        }

        public void set_BusNo(string BusNo)
        {
            this.BusNo = BusNo;
        }

        public void set_pickupDistance(string pickupDistance)
        {
            this.pickupDistance = pickupDistance;
        }

        public string get_pickupDistance()
        {
            return this.pickupDistance;
        }

        public string get_pickUPpoint()
        {
            return this.pickUPpoint;
        }

        public string get_BUSno()
        {
            return this.BusNo;
        }

        public override int get_fee(string subjects_registered)
        {
            int basic_fee = base.get_fee(this.subjects_registered);
            if (float.Parse(this.pickupDistance) >= 7)
            {
                basic_fee = basic_fee + 500;
            }

            return basic_fee;

        }

    }





    class Program
    {
        static void Main(string[] args)
        {
            Student_manager student_object = Student_manager.object_existance();
            string option = "0";
            Program program_object = new Program();
            while (option != "4")
            {
                program_object.main_menue();
                option = Console.ReadLine();
                if (option == "1")
                {
                    program_object.student_addition(student_object);
                }
                if (option == "2")
                {
                    program_object.menue_toshow();
                    string student_optionnumber = "0";
                    student_optionnumber = Console.ReadLine();
                    if (student_optionnumber == "1")
                    {
                        program_object.view_dayscholar(student_object);
                    }
                    if (student_optionnumber == "2")
                    {
                        program_object.view_hostillite(student_object);
                    }
                }

                if (option == "3")
                {
                    string name;
                    string session;
                    DayScholarBusfee data1;
                    Hostelite data2;
                    string isdayscholar = "";
                    Console.Write("ENTER YOUR NAME  =");
                    name = Console.ReadLine();
                    Console.Write("ENTER YOUR SESSION  =");
                    session = Console.ReadLine();
                    Console.Write("ENTER YES IF DAY SCHOLAR NO IF NOT  =");
                    isdayscholar = Console.ReadLine();
                    Console.Clear();

                    if (isdayscholar == "YES" || isdayscholar == "yes")
                    {
                        data1 = student_object.viewAll_Day_scholar_fee(name, session);
                        if (data1 != null)
                        {
                            Console.WriteLine("NAME" + "\t" + data1.name + "\t\n" + "SESSION" + "\t" + data1.session + "\t\n" + "DAY SCHOLAR" + "\t" + data1.isDayScholar + "\t\n" + "ENTRY TEST MARKS" + "\t" + data1.EntryTestMarks + "\t\n" + "MATRIC MARKS " + "\t" + data1.MatricMarks + "\t\n" + "FSC MARKS" + "\t" + data1.FscMarks + "\t\n" + "PICK UP DISTANCE" + data1.get_pickupDistance() + "\t\n" + "PICK UP POINT" + data1.get_pickUPpoint() + "\t\n" + "BUS NO" + data1.get_BUSno() + "\n" + "FEES  " + data1.get_fee(data1.subjects_registered));
                        }
                        else
                        {
                            program_object.invalid_record();
                        }
                    }
                    else
                    {
                        data2 = student_object.viewAll_hostelite_fee(name, session);
                        if (data2 != null)
                        {
                            Console.WriteLine("NAME" + "\t" + data2.name + "\t\n" + "SESSION" + "\t" + data2.session + "\t\n" + "DAY SCHOLAR" + "\t" + data2.isDayScholar + "\t\n" + "ENTRY TEST MARKS" + "\t" + data2.EntryTestMarks + "\t\n" + "MATRIC MARKS " + "\t" + data2.MatricMarks + "\t\n" + "FSC MARKS" + "\t" + data2.FscMarks + "\t\n" + "FRIDGE AVAILABLE" + "\t" + data2.get_isFridgeAvilable() + "\t\n" + "INTERNET AVAILIBILITY" + "\t" + data2.get_isInternetAvailable() + "\t\n" + "ROOM NUMBER" + "\t" + data2.get_roomNumber() + "\n" + "FEES  " + data2.get_fee(data2.subjects_registered));
                        }
                        else
                        {
                            program_object.invalid_record();
                        }

                    }
                    program_object.press_key();
                }
            }
        }


        void menue_toshow()
        {
            Console.Clear();
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("*                           STUDENT MANAGEMENT SYSTEM                   *");
            Console.WriteLine("*************************************************************************\n\n");
            Console.WriteLine("1.TO SEE DAY SCHOLAR \n");
            Console.WriteLine("2.TO SEE HOSTALLITES \n");
            Console.Write(" ENTER OPTION NUMBER =");

        }


        void press_key()
        {
            Console.WriteLine("PRESS ANY KEY TO CONTINUE ......................");
            Console.ReadLine();
        }

        void invalid_record()
        {
            Console.WriteLine("RECORD NOT FOUND................");

        }

        void view_dayscholar(Student_manager student_object)
        {

            ArrayList all_users = new ArrayList();
            all_users = student_object.viewAll_Day_scholar();
            for (int x = 0; x < all_users.Count; x++)
            {
                DayScholarBusfee temp = (DayScholarBusfee)all_users[x];
                Console.WriteLine("NAME" + "\t" + temp.name + "\t\n" + "SESSION" + "\t" + temp.session + "\t\n" + "DAY SCHOLAR" + "\t" + temp.isDayScholar + "\t\n" + "ENTRY TEST MARKS" + "\t" + temp.EntryTestMarks + "\t\n" + "MATRIC MARKS " + "\t" + temp.MatricMarks + "\t\n" + "FSC MARKS" + "\t" + temp.FscMarks + "\t\n" + "PICK UP DISTANCE" + temp.get_pickupDistance() + "\t\n" + "PICK UP POINT" + temp.get_pickUPpoint() + "\t\n" + "BUS NO" + temp.get_BUSno());
            }
            Console.ReadLine();
        }
        void view_hostillite(Student_manager student_object)
        {
            ArrayList all_users = new ArrayList();
            all_users = student_object.viewAll_Hostillite();

            for (int x = 0; x < all_users.Count; x++)
            {
                Hostelite temp = (Hostelite)all_users[x];
                Console.WriteLine("NAME" + "\t" + temp.name + "\t\n" + "SESSION" + "\t" + temp.session + "\t\n" + "DAY SCHOLAR" + "\t" + temp.isDayScholar + "\t\n" + "ENTRY TEST MARKS" + "\t" + temp.EntryTestMarks + "\t\n" + "MATRIC MARKS " + "\t" + temp.MatricMarks + "\t\n" + "FSC MARKS" + "\t" + temp.FscMarks + "\t\n" + "FRIDGE AVAILABLE" + "\t" + temp.get_isFridgeAvilable() + "\t\n" + "INTERNET AVAILIBILITY" + "\t" + temp.get_isInternetAvailable() + "\t\n" + "ROOM NUMBER" + "\t" + temp.get_roomNumber());
            }
            Console.ReadLine();
        }


        void main_menue()
        {
            Console.Clear();
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("*                           STUDENT MANAGEMENT SYSTEM                   *");
            Console.WriteLine("*************************************************************************\n\n");
            Console.WriteLine("WELCOME >>>>>> \n");
            Console.WriteLine("1.\tADD STUDENT");
            Console.WriteLine("2.\tVIEW STUDENT");
            Console.WriteLine("3.\tVIEW STUDENT FEE");
            Console.Write("ENTER OPTION NUMBER =");

        }
        void student_addition(Student_manager student_object)
        {
            string name = "";
            string session = "";
            bool isDayScholar = false;
            string isDayScholar_temp = "";
            string EntryTestMarks = "";
            string MatricMarks = "";
            string FscMarks = "";
            string subjects_registered = "";
            Console.Write("ENTER YOUR NAME  =");
            name = Console.ReadLine();
            Console.Write("ENTER YOUR SESSION  =");
            session = Console.ReadLine();
            Console.Write("ENTER YES IF DAY SCHOLAR NO IF NOT  =");
            isDayScholar_temp = Console.ReadLine();
            Console.Write("ENTER NUMBER OF SUBJECTS REGISTERED  =");
            subjects_registered = Console.ReadLine();
            if (isDayScholar_temp == "YES")
            {
                isDayScholar = true;
            }
            Console.Write("ENTER YOUR ENTRY TEST  =");
            EntryTestMarks = Console.ReadLine();
            Console.Write("ENTER YOUR MATRIC MARKS  =");
            MatricMarks = Console.ReadLine();
            Console.Write("ENTER YOUR FSC MARKS  =");
            FscMarks = Console.ReadLine();
            if (isDayScholar == true)
            {
                adding_dayscholar(student_object, name, session, isDayScholar, EntryTestMarks, MatricMarks, FscMarks, subjects_registered);

            }
            else
            {
                adding_hostalite(student_object, name, session, isDayScholar, EntryTestMarks, MatricMarks, FscMarks, subjects_registered);
            }
        }

        void adding_hostalite(Student_manager student_object, string name, string session, bool isDayScholar, string EntryTestMarks, string MatricMarks, string FscMarks, string subjects_registered)
        {
            string roomNumber = "";
            bool isFridgeAvilable = false;
            bool isInternetAvailable = false;
            string isFridgeAvilable_temp = "";
            string isInternetAvailable_temp = "";
            Console.Write("ENTER ROOM NUMBER  =");
            roomNumber = Console.ReadLine();
            Console.Write("ENTER YES IF FRIDGE AVAILABLE NO IF NOT  =");
            isFridgeAvilable_temp = Console.ReadLine();
            if (isFridgeAvilable_temp == "YES")
            {
                isFridgeAvilable = true;
            }
            Console.Write("ENTER YES IF INTERNET AVAILABLE NO IF NOT  =");
            isFridgeAvilable_temp = Console.ReadLine();
            if (isInternetAvailable_temp == "YES")
            {
                isInternetAvailable = true;
            }
            student_object.add_hostellite(name, session, isDayScholar, EntryTestMarks, MatricMarks, FscMarks, roomNumber, isFridgeAvilable, isInternetAvailable, subjects_registered);
            Console.WriteLine("STUDENT HAS BEEN ADDED SUCESSFULLY \n PRESS ANY KEY TO CONTINUE.............");
            Console.ReadLine();
        }



        void adding_dayscholar(Student_manager student_object, string name, string session, bool isDayScholar, string EntryTestMarks, string MatricMarks, string FscMarks, string subjects_registered)
        {
            string pickUPpoint = "";
            string BusNo = "";
            String pickupDistance = "";
            Console.Write("ENTER PICK UP POINT  =");
            pickUPpoint = Console.ReadLine();
            Console.Write("ENTER BUS NUMBER  =");
            BusNo = Console.ReadLine();
            Console.Write("ENTER PICK UP DISTANCE IN KM  =");
            pickupDistance = Console.ReadLine();
            student_object.add_dayscholar(name, session, isDayScholar, EntryTestMarks, MatricMarks, FscMarks, pickUPpoint, BusNo, pickupDistance, subjects_registered);
            Console.WriteLine("STUDENT HAS BEEN ADDED SUCESSFULLY \n PRESS ANY KEY TO CONTINUE.............");
            Console.ReadLine();
        }
    }
}

