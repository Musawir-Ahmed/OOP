﻿using System;
using System.Collections;
using System.Windows.Forms;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Text;
namespace _1_APP
{

    class User_manager
    {
        private ArrayList User_List = new ArrayList();

        private User_manager()
        { }
        static User_manager usercrud;
        public static User_manager object_existance()
        {
            if (usercrud == null)
            {
                usercrud = new User_manager();
            }
            return usercrud;
        }


        public void add_user_from_file(string name, string username, string emploiye_id, string password)
        {
            Admin admin_object = new Admin();
            admin_object.set_name(name);
            admin_object.set_username(username);
            admin_object.set_password(password);
            admin_object.set_employeid(emploiye_id);
            User_List.Add(admin_object);
        }
        public void add_user(string name, string username, string emploiye_id, string password)
        {
            if (name != "" && username != "" && emploiye_id != "" && password != "")
            {
                Admin admin_object = new Admin();
                admin_object.set_name(name);
                admin_object.set_username(username);
                admin_object.set_password(password);
                admin_object.set_employeid(emploiye_id);
                User_List.Add(admin_object);
                int length = User_List.Count;
                append_data_to_file(length);
            }

        }
        void append_data_to_file(int length)
        {
            length = length - 1;
            Admin data;
            string concationation;
            FileStream fs = new FileStream("E:\\C#\\WEEK-8\\DESKTOP-APPLICATION\\RECORD.txt", FileMode.Append, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            data = (Admin)User_List[length];
            concationation = data.get_name() + "," + data.get_username() + "," + data.get_password() + "," + data.get_employe_id() + ",";
            sw.WriteLine(concationation);
            sw.Flush();
            sw.Close();
            fs.Close();

        }
        public void readData()
        {
            string name = "";
            string username = "";
            string employe_id = "";
            string password = "";
            FileStream fs = new FileStream("E:\\C#\\WEEK-8\\DESKTOP-APPLICATION\\RECORD.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);
            sr.BaseStream.Seek(0, SeekOrigin.Begin);
            string str = "";
            str = sr.ReadLine();

            while (str != null)
            {
                name = getfield(str, 1);
                username = getfield(str, 2);
                password = getfield(str, 3);
                employe_id = getfield(str, 4);
                add_user_from_file(name, username, employe_id, password);
                str = sr.ReadLine();

            }
            sr.Close();
            fs.Close();





        }
        string getfield(string field, int comma)
        {
            string temp = "";
            int counter = 0;
            int starting_counter;
            int coma_counter = 0;
            starting_counter = comma - 1;

            while (coma_counter != comma)
            {

                if (field[counter] == ',')
                {
                    coma_counter = coma_counter + 1;
                    counter = counter + 1;
                }

                if (starting_counter <= coma_counter && coma_counter != comma)
                {
                    temp = temp + field[counter];
                }

                counter = counter + 1;
            }

            return temp;
        }
        public Admin user_validation(string employe_id, string password)
        {
            for (int x = 0; x < User_List.Count; x++)
            {
                Admin admin_object = (Admin)User_List[x];
                if (admin_object.get_employe_id() == employe_id && admin_object.get_password() == password)
                {
                    return admin_object;
                }
            }
            return null;
        }
    }
    class Admin
    {

        private string name = "";
        private string username = "";
        private string password = "";
        private string employe_id = "";

        public void set_name(string name)
        {
            this.name = name;
        }

        public string get_name()
        {
            return this.name;
        }


        public void set_username(string username)
        {
            this.username = username;
        }

        public string get_username()
        {
            return this.username;
        }

        public void set_password(string password)
        {
            this.password = password;
        }

        public string get_password()
        {
            return this.password;
        }


        public void set_employeid(string employe_id)
        {
            this.employe_id = employe_id;
        }

        public string get_employe_id()
        {
            return this.employe_id;
        }


    }
    class Main_window : Form
    {


        public Button singup_button, singin_button;


        public Main_window()
        {
            Console.ReadLine();
            main_screen_settings();
            main_screen_background_image();
            main_screen_button();

        }

        void main_screen_settings()
        {
            this.Size = new Size(600, 500);
            this.Text = "USER REGISTRATION";
            this.CenterToScreen();
        }

        void main_screen_background_image()
        {
            Image myimage = new Bitmap(@"E:\C#\WEEK-8\DESKTOP-APPLICATION\test3.png");
            this.BackgroundImage = myimage;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        void main_screen_button()
        {
            singin_button = new Button();
            singin_button.Location = new Point(200, 350);
            singin_button.Size = new Size(200, 40);
            singin_button.Text = "SIGIN IN";
            singin_button.ForeColor = Color.White;
            singin_button.Font = new Font("Calibri", 11);
            singin_button.BackColor = Color.RoyalBlue;
            singin_button.Click += new EventHandler(signin_button_click);
            this.Controls.Add(singin_button);



            singup_button = new Button();
            singup_button.Location = new Point(200, 395);
            singup_button.Size = new Size(200, 40);
            singup_button.Text = "SIGIN UP";
            singup_button.ForeColor = Color.White;
            singup_button.Font = new Font("Calibri", 11);
            singup_button.BackColor = Color.RoyalBlue;
            singup_button.Click += new EventHandler(signup_button_click);
            this.Controls.Add(singup_button);
        }


        private void signup_button_click(object sender, EventArgs e)
        {
            Signup_screen Signup_screen_object = new Signup_screen();
            Signup_screen_object.Show();
        }

        private void signin_button_click(object sender, EventArgs e)
        {
            Current_user_logedin_Manager.object_renover();
            Sigin_screen sigin_Screen_object = new Sigin_screen();
            sigin_Screen_object.Show();
        }


    }
    class Product_Manager
    {

        public ArrayList product_list = new ArrayList();

        private Product_Manager()
        { }
        static Product_Manager productcrud;
        public static Product_Manager object_existance()
        {
            if (productcrud == null)
            {
                productcrud = new Product_Manager();
            }
            return productcrud;
        }

        public void write_data_to_file(ArrayList temp)
        {

            Product data;
            string concationation;
            FileStream fs = new FileStream("E:\\C#\\WEEK-8\\DESKTOP-APPLICATION\\PRODUCTRECORD.txt", FileMode.Append, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            for (int x = 0; x < temp.Count; x++)
            {
                data = (Product)temp[x];
                concationation = data.product_name + "," + data.product_id + "," + data.product_price + "," + data.Product_stock + ",";
                sw.WriteLine(concationation);
            }
            sw.Flush();
            sw.Close();
            fs.Close();


        }




        public ArrayList readData()
        {
            product_list.Clear();
            string product_name = "";
            string product_id = "";
            string product_price = "";
            string product_stock = "";
            FileStream fs = new FileStream("E:\\C#\\WEEK-8\\DESKTOP-APPLICATION\\PRODUCTRECORD.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);
            sr.BaseStream.Seek(0, SeekOrigin.Begin);
            string str = "";
            str = sr.ReadLine();
            while (str != null)
            {
                product_name = getfield(str, 1);
                product_id = getfield(str, 2);
                product_price = getfield(str, 3);
                product_stock = getfield(str, 4);
                add_product(product_name, product_id, product_price, product_stock);
                str = sr.ReadLine();

            }
            sr.Close();
            fs.Close();

            return product_list;

        }
        string getfield(string field, int comma)
        {
            string temp = "";
            int counter = 0;
            int starting_counter;
            int coma_counter = 0;
            starting_counter = comma - 1;

            while (coma_counter != comma)
            {

                if (field[counter] == ',')
                {
                    coma_counter = coma_counter + 1;
                    counter = counter + 1;
                }

                if (starting_counter <= coma_counter && coma_counter != comma)
                {
                    temp = temp + field[counter];
                }

                counter = counter + 1;
            }

            return temp;
        }

        void add_product(string product_name, string product_id, string product_price, string product_stock)
        {
            Product product_object = new Product(product_name, product_id, product_price, product_stock);
            product_list.Add(product_object);
        }






    }

    class Product
    {
        public string product_name = "";
        public string product_id = "";
        public string product_price = "";
        public string Product_stock = "";

        public Product(string name, string id, string price, string stock)
        {
            this.product_name = name;
            this.product_id = id;
            this.product_price = price;
            this.Product_stock = stock;
        }
    }


    class Sigin_screen : Form
    {

        ArrayList temp = new ArrayList();
        TextBox password, employe_id;
        Label password_label, employe_id_label;

        public Sigin_screen()
        {
            third_screen_settings();
            signin_screen_background_image();
            input_signup_screen();
            labels();
            submit_button();
        }


        void third_screen_settings()
        {
            this.Size = new Size(1000, 500);
            this.Text = "SIGNUP";
            this.CenterToScreen();
        }

        void signin_screen_background_image()
        {
            Image myimage = new Bitmap(@"E:\C#\WEEK-8\DESKTOP-APPLICATION\test7.jpg");
            this.BackgroundImage = myimage;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        void input_signup_screen()
        {



            employe_id = new TextBox();
            employe_id.Location = new Point(400, 260);
            employe_id.Size = new Size(400, 100);
            employe_id.PlaceholderText = "ENTER YOUR EMPLOYE ID ";
            employe_id.Font = new Font("Calibri", 11);
            employe_id.ForeColor = Color.Black;
            this.Controls.Add(employe_id);



            password = new TextBox();
            password.Location = new Point(400, 300);
            password.Size = new Size(400, 100);
            password.PlaceholderText = "ENTER YOUR PASSWORD ";
            password.Font = new Font("Calibri", 11);
            password.ForeColor = Color.Black;
            this.Controls.Add(password);


        }

        void labels()
        {

            employe_id_label = new Label();
            employe_id_label.Text = "EMPLOYE ID";
            employe_id_label.Font = new Font("Calibri", 17);
            employe_id_label.ForeColor = Color.Black;
            employe_id_label.BackColor = Color.Transparent;
            employe_id_label.Location = new Point(240, 260);
            employe_id_label.AutoSize = true;
            this.Controls.Add(employe_id_label);

            password_label = new Label();
            password_label.Text = "PASSWORD";
            password_label.Font = new Font("Calibri", 17);
            password_label.ForeColor = Color.Black;
            password_label.BackColor = Color.Transparent;
            password_label.Location = new Point(240, 300);
            password_label.AutoSize = true;
            this.Controls.Add(password_label);

        }


        void submit_button()
        {
            Button submit = new Button();
            submit = new Button();
            submit.Location = new Point(500, 390);
            submit.Size = new Size(200, 40);
            submit.Text = "LOGIN";
            submit.ForeColor = Color.White;
            submit.Font = new Font("Calibri", 11);
            submit.BackColor = Color.RoyalBlue;
            submit.Click += new EventHandler(submit_button_click);
            this.Controls.Add(submit);

        }

        private void submit_button_click(object sender, EventArgs e)
        {
            Admin temp_object;
            User_manager user_Manager_object = User_manager.object_existance();
            temp_object = user_Manager_object.user_validation(employe_id.Text, password.Text);
            if (temp_object != null)
            {
                this.Close();
                ADD_PRODUCT add_product_object = new ADD_PRODUCT();
                Current_user_logedin_Manager user_logegin = Current_user_logedin_Manager.object_existance();
                user_logegin.logedin_user(temp_object.get_name(), temp_object.get_username(), temp_object.get_password(), temp_object.get_employe_id());
                add_product_object.Show();

            }
        }


    }
    class Signup_screen : Form
    {

        Label name_label, usernamee_label, password_label, employe_id_label;
        TextBox user_name, password, name, employe_id;

        public Signup_screen()
        {

            scond_screen_settings();
            signup_screen_background_image();
            input_signup_screen();
            labels();
            submit_button();
        }

        void input_signup_screen()
        {

            name = new TextBox();
            name.Location = new Point(400, 220);
            name.Size = new Size(400, 100);
            name.PlaceholderText = "ENTER YOUR NAME ";
            name.Font = new Font("Calibri", 11);
            name.ForeColor = Color.Black;
            this.Controls.Add(name);

            employe_id = new TextBox();
            employe_id.Location = new Point(400, 260);
            employe_id.Size = new Size(400, 100);
            employe_id.PlaceholderText = "ENTER YOUR EMPLOYE ID ";
            employe_id.Font = new Font("Calibri", 11);
            employe_id.ForeColor = Color.Black;
            this.Controls.Add(employe_id);

            user_name = new TextBox();
            user_name.Location = new Point(400, 300);
            user_name.Size = new Size(400, 100);
            user_name.PlaceholderText = "ENTER USER NAME ";
            user_name.Font = new Font("Calibri", 11);
            user_name.ForeColor = Color.Black;
            this.Controls.Add(user_name);

            password = new TextBox();
            password.Location = new Point(400, 340);
            password.Size = new Size(400, 100);
            password.PlaceholderText = "ENTER YOUR PASSWORD ";
            password.Font = new Font("Calibri", 11);
            password.ForeColor = Color.Black;
            this.Controls.Add(password);


        }

        void labels()
        {
            //200 220
            name_label = new Label();
            name_label.Text = "NAME";
            name_label.Font = new Font("Calibri", 17);
            name_label.ForeColor = Color.Black;
            name_label.BackColor = Color.Transparent;
            name_label.Location = new Point(240, 219);
            name_label.AutoSize = true;
            this.Controls.Add(name_label);

            usernamee_label = new Label();
            usernamee_label.Text = "EMPLOYE ID ";
            usernamee_label.Font = new Font("Calibri", 17);
            usernamee_label.ForeColor = Color.Black;
            usernamee_label.BackColor = Color.Transparent;
            usernamee_label.Location = new Point(240, 259);
            usernamee_label.AutoSize = true;
            this.Controls.Add(usernamee_label);


            password_label = new Label();
            password_label.Text = "USER NAME";
            password_label.Font = new Font("Calibri", 17);
            password_label.ForeColor = Color.Black;
            password_label.BackColor = Color.Transparent;
            password_label.Location = new Point(240, 299);
            password_label.AutoSize = true;
            this.Controls.Add(password_label);



            employe_id_label = new Label();
            employe_id_label.Text = "PASSWORD ";
            employe_id_label.Font = new Font("Calibri", 17);
            employe_id_label.ForeColor = Color.Black;
            employe_id_label.BackColor = Color.Transparent;
            employe_id_label.Location = new Point(240, 339);
            employe_id_label.AutoSize = true;
            this.Controls.Add(employe_id_label);


        }

        void scond_screen_settings()
        {
            this.Size = new Size(1000, 500);
            this.Text = "SIGNUP";
            this.CenterToScreen();
        }


        void submit_button()
        {
            Button submit = new Button();
            submit = new Button();
            submit.Location = new Point(500, 410);
            submit.Size = new Size(200, 40);
            submit.Text = "SUBMIT";
            submit.ForeColor = Color.White;
            submit.Font = new Font("Calibri", 11);
            submit.BackColor = Color.RoyalBlue;
            submit.Click += new EventHandler(submit_button_click);
            this.Controls.Add(submit);

        }




        void signup_screen_background_image()
        {
            Image myimage = new Bitmap(@"E:\C#\WEEK-8\DESKTOP-APPLICATION\test7.jpg");
            this.BackgroundImage = myimage;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        private void submit_button_click(object sender, EventArgs e)
        {
            this.Hide();
            User_manager usermanager_object = User_manager.object_existance();
            usermanager_object.add_user(name.Text, user_name.Text, employe_id.Text, password.Text);
        }



    }

    class Current_user_logedin_Manager
    {
        public string username;
        public string employe_id;
        public string password;
        public string name;
        private Current_user_logedin_Manager()
        { }
        static Current_user_logedin_Manager user_temp;
        public static Current_user_logedin_Manager object_existance()
        {
            if (user_temp == null)
            {
                user_temp = new Current_user_logedin_Manager();
            }
            return user_temp;
        }
        public void logedin_user(string name, string username, string password, string employe_id)
        {
            this.name = name;
            this.username = username;
            this.password = password;
            this.employe_id = employe_id;
        }
        public static void object_renover()
        {
            user_temp = null;
        }


    }



    class MAIN_funtions : Form
    {


        public void screen_settings()
        {
            this.Size = new Size(1300, 650);
            this.Text = "HOMW EMPLOYE DETAILS";
            this.CenterToScreen();
        }

        public void screen_background_image()
        {
            Image myimage = new Bitmap(@"E:\C#\WEEK-8\DESKTOP-APPLICATION\BACK.JPG");
            this.BackgroundImage = myimage;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }
        public void buttons()
        {
            Button HOME = new Button();
            HOME = new Button();
            Image HOME_image = new Bitmap(@"E:\C#\WEEK-8\DESKTOP-APPLICATION\BUTTON.PNG");
            HOME.BackgroundImage = HOME_image;
            HOME.BackgroundImageLayout = ImageLayout.Stretch;
            HOME.Location = new Point(0, 0);
            HOME.Size = new Size(50, 50);
            HOME.ForeColor = Color.Black;
            HOME.BackColor = Color.RoyalBlue;
            HOME.Click += new EventHandler(HOME_button_click);
            this.Controls.Add(HOME);

            Button Add_product = new Button();
            Add_product = new Button();
            Image ADD_product_image = new Bitmap(@"E:\C#\WEEK-8\DESKTOP-APPLICATION\ADD_PRODUCT.JPG");
            Add_product.BackgroundImage = ADD_product_image;
            Add_product.BackgroundImageLayout = ImageLayout.Stretch;
            Add_product.Location = new Point(50, 0);
            Add_product.Size = new Size(50, 50);
            Add_product.ForeColor = Color.Black;
            Add_product.Font = new Font("Calibri", 16);
            Add_product.BackColor = Color.RoyalBlue;
            Add_product.Click += new EventHandler(ADD_button_click);

            this.Controls.Add(Add_product);

            Button View_all_product = new Button();
            View_all_product = new Button();
            Image View_all_product_image = new Bitmap(@"E:\C#\WEEK-8\DESKTOP-APPLICATION\VIEW_ALL-1.JPG");
            View_all_product.BackgroundImage = View_all_product_image;
            View_all_product.BackgroundImageLayout = ImageLayout.Stretch;
            View_all_product.Location = new Point(100, 0);
            View_all_product.Size = new Size(50, 50);
            View_all_product.ForeColor = Color.Black;
            View_all_product.BackColor = Color.RoyalBlue;
            View_all_product.Click += new EventHandler(VIEW_button_click);
            this.Controls.Add(View_all_product);




        }

        private void HOME_button_click(object sender, EventArgs e)
        {
            this.Close();
            HOME home_object = new HOME();
            home_object.Show();
        }

        private void ADD_button_click(object sender, EventArgs e)
        {
            this.Close();
            ADD_PRODUCT ADD_PRODUCT_object = new ADD_PRODUCT();
            ADD_PRODUCT_object.Show();
        }

        private void VIEW_button_click(object sender, EventArgs e)
        {
            this.Close();
            VIEW_ALL_PRODUCT View_all_object = new VIEW_ALL_PRODUCT();
            View_all_object.Show();
        }


    }


    class HOME : MAIN_funtions
    {

        public HOME()
        {
            screen_settings();
            BackColor = Color.WhiteSmoke;
            buttons();
            employe_details();
        }
        private void employe_details()
        {
            Current_user_logedin_Manager user_object = Current_user_logedin_Manager.object_existance();
            DataGridView mydatagrid = new DataGridView();
            mydatagrid.Location = new Point(0, 90);
            mydatagrid.AutoSize = true;
            mydatagrid.ReadOnly = true;
            mydatagrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            mydatagrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            mydatagrid.ColumnCount = 2;
            mydatagrid.Rows.Add("------------EMPLOYE", "DETAILS-------------------");
            mydatagrid.Rows.Add("\n");
            mydatagrid.Rows.Add("NAME", user_object.name);
            mydatagrid.Rows.Add("USER NAME", user_object.username);
            mydatagrid.Rows.Add("PASSWORD", user_object.password);
            mydatagrid.Rows.Add("EMPLOYE ID", user_object.employe_id);
            mydatagrid.Font = new Font("Calibri", 20);
            this.Controls.Add(mydatagrid);

        }

    }



    class ADD_PRODUCT : MAIN_funtions
    {
        ArrayList temp = new ArrayList();
        DataGridView mydatagrid;
        TextBox product_name, product_id, product_price, product_stock;

        public ADD_PRODUCT()
        {
            BackColor = Color.WhiteSmoke;
            screen_settings();
            buttons();
            input_textboxes();
            labels();
            product_list();
            add_button();
            add_to_file_button();
        }

        void input_textboxes()
        {
            product_name = new TextBox();
            product_name.Location = new Point(50, 130);
            product_name.Size = new Size(400, 100);
            product_name.PlaceholderText = "PRODUCT NAME";
            product_name.Font = new Font("Calibri", 11);
            product_name.ForeColor = Color.Black;
            this.Controls.Add(product_name);

            product_id = new TextBox();
            product_id.Location = new Point(50, 210);
            product_id.Size = new Size(400, 100);
            product_id.PlaceholderText = "PRODUCT ID ";
            product_id.Font = new Font("Calibri", 11);
            product_id.ForeColor = Color.Black;
            this.Controls.Add(product_id);

            product_price = new TextBox();
            product_price.Location = new Point(50, 290);
            product_price.Size = new Size(400, 100);
            product_price.PlaceholderText = "PRODUCT PRICE ";
            product_price.Font = new Font("Calibri", 11);
            product_price.ForeColor = Color.Black;
            this.Controls.Add(product_price);

            product_stock = new TextBox();
            product_stock.Location = new Point(50, 370);
            product_stock.Size = new Size(400, 100);
            product_stock.PlaceholderText = "PRODUCT STOCK";
            product_stock.Font = new Font("Calibri", 11);
            product_stock.ForeColor = Color.Black;
            this.Controls.Add(product_stock);



        }

        void labels()
        {
            Label product_name, product_id, product_price, product__stock;
            //200 220
            product_name = new Label();
            product_name.Text = "PRODUCT NAME";
            product_name.Font = new Font("Calibri", 15);
            product_name.ForeColor = Color.Black;
            product_name.BackColor = Color.Transparent;
            product_name.Location = new Point(50, 100);
            product_name.AutoSize = true;
            this.Controls.Add(product_name);

            product_id = new Label();
            product_id.Text = "PRODUCT ID";
            product_id.Font = new Font("Calibri", 15);
            product_id.ForeColor = Color.Black;
            product_id.BackColor = Color.Transparent;
            product_id.Location = new Point(50, 180);
            product_id.AutoSize = true;
            this.Controls.Add(product_id);


            product_price = new Label();
            product_price.Text = "PRODUCT PRICE";
            product_price.Font = new Font("Calibri", 15);
            product_price.ForeColor = Color.Black;
            product_price.BackColor = Color.Transparent;
            product_price.Location = new Point(50, 260);
            product_price.AutoSize = true;
            this.Controls.Add(product_price);



            product__stock = new Label();
            product__stock.Text = "PRODUCT STOCK";
            product__stock.Font = new Font("Calibri", 15);
            product__stock.ForeColor = Color.Black;
            product__stock.BackColor = Color.Transparent;
            product__stock.Location = new Point(50, 340);
            product__stock.AutoSize = true;
            this.Controls.Add(product__stock);
        }

        public void product_list()
        {
            mydatagrid = new DataGridView();
            mydatagrid.Location = new Point(530, 100);
            mydatagrid.AutoSize = true;
            mydatagrid.ReadOnly = true;
            mydatagrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            mydatagrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            mydatagrid.ColumnCount = 4;
            mydatagrid.Rows.Add("PRODUCT NAME", "PRODUCT ID", "PRODUCT PRICE", "PRODUCT STOCK");


            mydatagrid.Font = new Font("Calibri", 14);
            this.Controls.Add(mydatagrid);
        }

        void add_button()
        {
            Button add_button = new Button();
            add_button.Location = new Point(50, 420);
            add_button.Size = new Size(200, 40);
            add_button.Text = "ADD TO LIST";
            add_button.ForeColor = Color.White;
            add_button.Font = new Font("Calibri", 11);
            add_button.BackColor = Color.RoyalBlue;
            add_button.Click += new EventHandler(add_to_list);
            this.Controls.Add(add_button);
        }

        void add_to_file_button()
        {
            Button file_button = new Button();
            file_button.Location = new Point(300, 420);
            file_button.Size = new Size(200, 40);
            file_button.Text = "ADD TO FILE";
            file_button.ForeColor = Color.White;
            file_button.Font = new Font("Calibri", 11);
            file_button.BackColor = Color.RoyalBlue;
            file_button.Click += new EventHandler(add_to_file);

            this.Controls.Add(file_button);
        }
        public void add_to_row(string c1, string c2, string c3, string c4)
        {
            String[] row = { c1, c2, c3, c4 };
            mydatagrid.Rows.Add(row);
        }
        private void add_to_list(object sender, EventArgs e)
        {
            if (product_name.Text != "" && product_id.Text != "" && product_price.Text != "" && product_stock.Text != "")
            {
                add_to_row(product_name.Text, product_id.Text, product_price.Text, product_stock.Text);

                Product product_list_object = new Product(product_name.Text, product_id.Text, product_price.Text, product_stock.Text);
                temp.Add(product_list_object);
                product_name.Text = "";
                product_id.Text = "";
                product_price.Text = "";
                product_stock.Text = "";
            }
        }

        private void add_to_file(object sender, EventArgs e)
        {
            if (temp != null)
            {
                Product_Manager product_Manager_object = Product_Manager.object_existance();
                product_Manager_object.write_data_to_file(temp);
                temp = null;
                this.Close();
                ADD_PRODUCT ADD_PRODUCT_object = new ADD_PRODUCT();
                ADD_PRODUCT_object.Show();
            }
        }


    }


    class VIEW_ALL_PRODUCT : MAIN_funtions
    {


        ArrayList product_list = new ArrayList();
        DataGridView mydatagrid;


        public VIEW_ALL_PRODUCT()
        {
            screen_settings();
            BackColor = Color.Gray;
            screen_background_image();
            buttons();
            product_list = null;
            Product_Manager product_object = Product_Manager.object_existance();
            product_list = product_object.readData();
            view_product_stored();

        }

        void view_product_stored()
        {

            mydatagrid = new DataGridView();
            mydatagrid.Location = new Point(100, 100);
            mydatagrid.AutoSize = true;
            mydatagrid.ReadOnly = true;
            mydatagrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            mydatagrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            mydatagrid.ColumnCount = 4;
            mydatagrid.Rows.Add("PRODUCT NAME", "PRODUCT ID", "PRODUCT PRICE", "PRODUCT STOCK");
            Product product_data_list;
            for (int x = 0; x < product_list.Count; x++)
            {
                product_data_list = (Product)product_list[x];
                mydatagrid.Rows.Add(product_data_list.product_name, product_data_list.product_id, product_data_list.product_price, product_data_list.Product_stock);
            }
            mydatagrid.Font = new Font("Calibri", 17);
            this.Controls.Add(mydatagrid);

        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            User_manager user_Manager_object = User_manager.object_existance();
            user_Manager_object.readData();
            Main_window main_Window_object = new Main_window();
            Application.EnableVisualStyles();
            Application.Run(main_Window_object);


        }



    }

}
