﻿using System;
using System.Collections;

namespace INHERITANCE
{

    class Student_manager
    {
        private ArrayList Hostelite_List = new ArrayList();
        private ArrayList DayScholar_List = new ArrayList();

        private Student_manager()
        { }
        static Student_manager studentManager_object;
        public static Student_manager object_existance()
        {
            if (studentManager_object == null)
            {
                studentManager_object = new Student_manager();
            }
            return studentManager_object;
        }

        public void add_hostellite(string name, string session, bool isDayScholar, string EntryTestMarks, string MatricMarks, string FscMarks, string roomNumber, bool isFridgeAvilable, bool isInternetAvailable)
        {
            Hostelite Hostelite_object = new Hostelite();
            Hostelite_object.name = name;
            Hostelite_object.session = session;
            Hostelite_object.isDayScholar = isDayScholar;
            Hostelite_object.EntryTestMarks = EntryTestMarks;
            Hostelite_object.MatricMarks = MatricMarks;
            Hostelite_object.FscMarks = FscMarks;
            Hostelite_object.set_roomNumber(roomNumber);
            Hostelite_object.set_isFridgeAvilable(isFridgeAvilable);
            Hostelite_object.set_isInternetAvailable(isInternetAvailable);
            Hostelite_List.Add(Hostelite_object);
        }
        public void add_dayscholar(string name, string session, bool isDayScholar, string EntryTestMarks, string MatricMarks, string FscMarks, string pickUPpoint, string BusNo, String pickupDistance)
        {
            DayScholarBusfee DayScholarBusfee_object = new DayScholarBusfee();
            DayScholarBusfee_object.name = name;
            DayScholarBusfee_object.session = session;
            DayScholarBusfee_object.isDayScholar = isDayScholar;
            DayScholarBusfee_object.EntryTestMarks = EntryTestMarks;
            DayScholarBusfee_object.MatricMarks = MatricMarks;
            DayScholarBusfee_object.FscMarks = FscMarks;
            DayScholarBusfee_object.set_BusNo(BusNo);
            DayScholarBusfee_object.set_pickUPpoint(pickUPpoint);
            DayScholarBusfee_object.set_pickupDistance(pickupDistance);
            DayScholar_List.Add(DayScholarBusfee_object);

        }

        public ArrayList viewAll_Day_scholar()
        {
            ArrayList all_users = new ArrayList();
            for (int x = 0; x < DayScholar_List.Count; x++)
            {
                all_users.Add(DayScholar_List[x]);
            }
            return all_users;
        }

        public ArrayList viewAll_Hostillite()
        {
            ArrayList all_users = new ArrayList();
            for (int x = 0; x < Hostelite_List.Count; x++)
            {
                all_users.Add(Hostelite_List[x]);
            }
            return all_users;
        }


    }


    class Student
    {
        public string name = "";
        public string session = "";
        public bool isDayScholar = false;
        public string EntryTestMarks = "";
        public string MatricMarks = "";
        public string FscMarks = "";

        public float calculationMerit()
        {
            float merit = 0;
            merit = float.Parse(this.EntryTestMarks) / 30 + float.Parse(this.FscMarks) / 45 + float.Parse(this.MatricMarks) / 25;
            return merit;
        }

    }

    class Hostelite : Student
    {
        private string roomNumber = "";
        private bool isFridgeAvilable = false;
        private bool isInternetAvailable = false;
        public void set_roomNumber(string roomNumber)
        {
            this.roomNumber = roomNumber;
        }

        public void set_isFridgeAvilable(bool isFridgeAvilable)
        {
            this.isFridgeAvilable = isFridgeAvilable;
        }

        public void set_isInternetAvailable(bool isInternetAvailable)
        {
            this.isInternetAvailable = isInternetAvailable;
        }

        public string get_roomNumber()
        {
            return this.roomNumber;
        }

        public bool get_isFridgeAvilable()
        {
            return this.isFridgeAvilable;
        }

        public bool get_isInternetAvailable()
        {
            return this.isInternetAvailable;
        }

        public int get_hostel_fee()
        {
            if (this.isFridgeAvilable == true && this.isInternetAvailable == true)
            {
                return 1000;
            }

            else if (this.isFridgeAvilable == true || this.isInternetAvailable == true)
            {
                return 500;
            }

            return 300;
        }



    }

    class DayScholarBusfee : Student
    {
        string pickUPpoint = "";
        string BusNo = "";
        String pickupDistance = "";
        public void set_pickUPpoint(string pickUPpoint)
        {
            this.pickUPpoint = pickUPpoint;
        }

        public void set_BusNo(string BusNo)
        {
            this.BusNo = BusNo;
        }

        public void set_pickupDistance(string pickupDistance)
        {
            this.pickupDistance = pickupDistance;
        }

        public string get_pickupDistance()
        {
            return this.pickupDistance;
        }

        public string get_pickUPpoint()
        {
            return this.pickUPpoint;
        }

        public string get_BUSno()
        {
            return this.BusNo;
        }




        public int getBusfee()
        {
            if (float.Parse(this.pickupDistance) > 5)
            {
                return 500;
            }
            return 300;
        }

    }





    class Program
    {
        static void Main(string[] args)
        {
            Student_manager student_object = Student_manager.object_existance();
            int option = 0;
            Program program_object = new Program();
            while (option != 3)
            {
                program_object.main_menue();
                option = int.Parse(Console.ReadLine());
                if (option == 1)
                {
                    program_object.student_addition(student_object);
                }
                if (option == 2)
                {
                    program_object.menue_toshow();
                    int student_optionnumber = 0;
                    student_optionnumber = int.Parse(Console.ReadLine());
                    if (student_optionnumber == 1)
                    {
                        program_object.view_dayscholar(student_object);
                    }
                    if (student_optionnumber == 2)
                    {
                        program_object.view_hostillite(student_object);
                    }
                }
            }
        }


        void menue_toshow()
        {
            Console.Clear();
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("*                           STUDENT MANAGEMENT SYSTEM                   *");
            Console.WriteLine("*************************************************************************\n\n");
            Console.WriteLine("1.TO SEE DAY SCHOLAR \n");
            Console.WriteLine("2.TO SEE HOSTALLITES \n");
            Console.Write(" ENTER OPTION NUMBER =");

        }

        void view_dayscholar(Student_manager student_object)
        {

            ArrayList all_users = new ArrayList();
            all_users = student_object.viewAll_Day_scholar();
            Console.WriteLine("NAME" + "\t" + "SESSION" + "\t" + "DAY SCHOLAR" + "\t" + "ENTRY TEST MARKS" + "\t" + "MATRIC MARKS " + "\t" + "FSC MARKS" + "\t" + "PICK UP DISTANCE" + "\t" + "PICKUP POINT" + "\t" + "BUS NUMBER" + "\t");

            for (int x = 0; x < all_users.Count; x++)
            {
                DayScholarBusfee temp = (DayScholarBusfee)all_users[x];
                Console.WriteLine(temp.name + "\t" + temp.session + "\t" + temp.isDayScholar + "\t" + temp.EntryTestMarks + "\t" + "\t" + temp.MatricMarks + "\t" + temp.FscMarks + "\t" + temp.get_pickupDistance() + "\t" + temp.get_pickUPpoint() + "\t" + temp.get_BUSno());
            }
            Console.ReadLine();
        }
        void view_hostillite(Student_manager student_object)
        {
            ArrayList all_users = new ArrayList();
            all_users = student_object.viewAll_Hostillite();
            Console.WriteLine("NAME" + "\t" + "SESSION" + "\t" + "DAY SCHOLAR" + "\t" + "ENTRY TEST MARKS" + "\t" + "MATRIC MARKS " + "\t" + "FSC MARKS" + "\t" + "FRIDGE AVAILABLE" + "\t" + "INTERNET AVAILIBILITY" + "\t" + "ROOM NUMBER" + "\t");

            for (int x = 0; x < all_users.Count; x++)
            {
                Hostelite temp = (Hostelite)all_users[x];
                Console.WriteLine(temp.name + "\t" + temp.session + "\t" + temp.isDayScholar + "\t" + temp.EntryTestMarks + "\t" + temp.MatricMarks + "\t" + temp.MatricMarks + "\t" + temp.FscMarks + "\t" + temp.get_isFridgeAvilable() + "\t" + temp.get_isInternetAvailable() + "\t" + temp.get_roomNumber());
            }
            Console.ReadLine();
        }


        void main_menue()
        {
            Console.Clear();
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("*                           STUDENT MANAGEMENT SYSTEM                   *");
            Console.WriteLine("*************************************************************************\n\n");
            Console.WriteLine("WELCOME >>>>>> \n");
            Console.WriteLine("1.\tADD STUDENT");
            Console.WriteLine("2.\tVIEW STUDENT");
            Console.Write("ENTER OPTION NUMBER =");

        }
        void student_addition(Student_manager student_object)
        {
            string name = "";
            string session = "";
            bool isDayScholar = false;
            string isDayScholar_temp = "";
            string EntryTestMarks = "";
            string MatricMarks = "";
            string FscMarks = "";
            Console.Write("ENTER YOUR NAME");
            name = Console.ReadLine();
            Console.Write("ENTER YOUR SESSION");
            session = Console.ReadLine();
            Console.Write("ENTER YES IF DAY SCHOLAR NO IF NOT =");
            isDayScholar_temp = Console.ReadLine();
            if (isDayScholar_temp == "YES")
            {
                isDayScholar = true;
            }
            Console.Write("ENTER YOUR ENTRY TEST =");
            EntryTestMarks = Console.ReadLine();
            Console.Write("ENTER YOUR MATRIC MARKS =");
            MatricMarks = Console.ReadLine();
            Console.Write("ENTER YOUR FSC MARKS =");
            FscMarks = Console.ReadLine();
            if (isDayScholar == true)
            {
                adding_dayscholar(student_object, name, session, isDayScholar, EntryTestMarks, MatricMarks, FscMarks);

            }
            else
            {
                adding_hostalite(student_object, name, session, isDayScholar, EntryTestMarks, MatricMarks, FscMarks);
            }
        }

        void adding_hostalite(Student_manager student_object, string name, string session, bool isDayScholar, string EntryTestMarks, string MatricMarks, string FscMarks)
        {
            string roomNumber = "";
            bool isFridgeAvilable = false;
            bool isInternetAvailable = false;
            string isFridgeAvilable_temp = "";
            string isInternetAvailable_temp = "";
            Console.WriteLine("ENTER ROOM NUMBER =");
            roomNumber = Console.ReadLine();
            Console.WriteLine("ENTER YES IF FRIDGE AVAILABLE NO IF NOT  =");
            isFridgeAvilable_temp = Console.ReadLine();
            if (isFridgeAvilable_temp == "YES")
            {
                isFridgeAvilable = true;
            }
            Console.WriteLine("ENTER YES IF INTERNET AVAILABLE NO IF NOT  =");
            isFridgeAvilable_temp = Console.ReadLine();
            if (isInternetAvailable_temp == "YES")
            {
                isInternetAvailable = true;
            }
            student_object.add_hostellite(name, session, isDayScholar, EntryTestMarks, MatricMarks, FscMarks, roomNumber, isFridgeAvilable, isInternetAvailable);
            Console.WriteLine("STUDENT HAS BEEN ADDED SUCESSFULLY \n PRESS ANY KEY TO CONTINUE.............");
            Console.ReadLine();
        }



        void adding_dayscholar(Student_manager student_object, string name, string session, bool isDayScholar, string EntryTestMarks, string MatricMarks, string FscMarks)
        {
            string pickUPpoint = "";
            string BusNo = "";
            String pickupDistance = "";
            Console.WriteLine("ENTER PICK UP POINT =");
            pickUPpoint = Console.ReadLine();
            Console.WriteLine("ENTER BUS NUMBER =");
            BusNo = Console.ReadLine();
            Console.WriteLine("ENTER PICK UP DISTANCE IN KM =");
            pickupDistance = Console.ReadLine();
            student_object.add_dayscholar(name, session, isDayScholar, EntryTestMarks, MatricMarks, FscMarks, pickUPpoint, BusNo, pickupDistance);
            Console.WriteLine("STUDENT HAS BEEN ADDED SUCESSFULLY \n PRESS ANY KEY TO CONTINUE.............");
            Console.ReadLine();
        }
    }
}
