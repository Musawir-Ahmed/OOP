﻿using System;
using System.Collections;
using System.Windows.Forms;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Text;

namespace ASSIGNMENT_1
{

    class Main_window : Form
    {

        public Main_window()
        {
            screen_settings();
            button();
        }

        public void screen_settings()
        {
            this.Size = new Size(1000, 500);
            this.Text = "SIGNUP";
            this.CenterToScreen();
        }

        private void button()
        {
            Button Click = new Button();
            Click = new Button();
            Click.Location = new Point(500, 390);
            Click.Size = new Size(200, 40);
            Click.Text = "CLICK ME";
            Click.ForeColor = Color.Black;
            Click.Font = new Font("Calibri", 17);
            Click.BackColor = Color.RoyalBlue;
            Click.Click += new EventHandler(button_click);
            this.Controls.Add(Click);

        }

        private void button_click(object sender, EventArgs e)
        {

            TextBox test = new TextBox();
            test.Location = new Point(400, 260);
            test.AutoSize = true;
            test.PlaceholderText = "HELLO WORLD";
            test.Font = new Font("Calibri", 19);
            test.ForeColor = Color.Black;
            this.Controls.Add(test);
        }


    }


    class Program
    {
        static void Main(string[] args)
        {

            Main_window main_Window_object = new Main_window();
            Application.EnableVisualStyles();
            Application.Run(main_Window_object);
        }
    }
}
