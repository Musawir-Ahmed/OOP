﻿using System;
using System.Collections;
using System.Windows.Forms;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Text;

namespace ASSIGNMENT_1
{

    class Main_window : Form
    {

        public Main_window()
        {
            screen_settings();
            button();
        }

        void screen_settings()
        {
            this.Size = new Size(1000, 500);
            this.Text = "SIGNUP";
            this.CenterToScreen();
        }

        void button()
        {
            Button Click = new Button();
            Click = new Button();
            Click.Location = new Point(500, 390);
            Click.Size = new Size(200, 40);
            Click.Text = "CLICK ME";
            Click.ForeColor = Color.Black;
            Click.Font = new Font("Calibri", 17);
            Click.BackColor = Color.RoyalBlue;
            Click.Click += new EventHandler(button_click);
            this.Controls.Add(Click);

        }

        private void button_click(object sender, EventArgs e)
        {
            Label hello_label = new Label();
            hello_label.Text = "HELLO WORLD";
            hello_label.Font = new Font("Calibri", 17);
            hello_label.ForeColor = Color.Black;
            hello_label.BackColor = Color.Transparent;
            hello_label.Location = new Point(240, 219);
            hello_label.AutoSize = true;
            this.Controls.Add(hello_label);
        }


    }

    class Program
    {
        static void Main(string[] args)
        {

            Main_window main_Window_object = new Main_window();
            Application.EnableVisualStyles();
            Application.Run(main_Window_object);
        }
    }
}
