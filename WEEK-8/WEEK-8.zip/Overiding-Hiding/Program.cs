﻿using System;

namespace Overiding_Hiding
{

    class Vechical
    {

        virtual public string speed()
        {
            return "VECHICAL CLASS SPEED";
        }

        public String Average()
        {
            return "VECHICAL CLASS AVERAGE";

        }
    }

    class Car : Vechical
    {
        override public string speed()
        {
            return "CAR CLASS SPEED";
        }

        public String Average()
        {
            return "CAR CLASS AVERAGE";

        }


    }


    class Program
    {
        static void Main(string[] args)
        {

            string return_message;

            Vechical vechical_object = new Vechical();
            Car car_object = new Car();

            ////VECHICAL
            return_message = vechical_object.speed();
            Console.WriteLine(return_message);
            return_message = vechical_object.Average();
            Console.WriteLine(return_message);
            //CAR
            return_message = car_object.speed();
            Console.WriteLine(return_message);
            return_message = car_object.Average();
            Console.WriteLine(return_message);
            //ASSIGNING OF INSTANCE
            vechical_object = car_object;
            return_message = vechical_object.speed();
            Console.WriteLine(return_message);
            return_message = vechical_object.Average();
            Console.WriteLine(return_message);


        }
    }
}
